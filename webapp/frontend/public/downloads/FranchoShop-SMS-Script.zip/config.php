<?php
/**
 * Configuración del Sistema de Números Virtuales (SMS Reseller)
 * Francho Shop B2B Standalone Script
 */

// Evitar acceso directo
if (!defined('SMS_SYSTEM')) {
    define('SMS_SYSTEM', true);
}

// URL base de la API oficial de Francho Shop
define('FRANCHO_API_BASE_URL', 'https://franchoshop.com/api/v1/reseller');

// Token / API Key de revendedor de Francho Shop
// Puedes pegarlo aquí o guardarlo directamente desde el panel de administración (admin.php)
define('DEFAULT_API_KEY', 'PEGA_TU_API_KEY_AQUI');

// Contraseña por defecto para ingresar a admin.php (cámbiala en tu primer ingreso)
define('DEFAULT_ADMIN_PASSWORD', 'admin123');

// Margen de ganancia por defecto en porcentaje (%)
// Ejemplo: 25 significa que si Francho cobra $1.00 USDT, la tienda vende a $1.25 USDT
define('DEFAULT_MARKUP_PERCENT', 25.0);

// Nombre de la tienda
define('DEFAULT_STORE_NAME', 'Virtual SMS Hub');

// Color temático primario (estilo Francho Shop: verde esmeralda neón)
define('DEFAULT_PRIMARY_COLOR', '#00C26F');

// Moneda de cobro y visualización
define('CURRENCY_NAME', 'USDT');
